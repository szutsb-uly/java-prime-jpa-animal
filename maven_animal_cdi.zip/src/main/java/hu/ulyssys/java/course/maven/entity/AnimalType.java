package hu.ulyssys.java.course.maven.entity;

public enum AnimalType {
    DOG, CAT, SLUG
}
