package hu.ulyssys.java.course.maven;

import hu.ulyssys.java.course.maven.entity.Cat;
import hu.ulyssys.java.course.maven.entity.Dog;
import hu.ulyssys.java.course.maven.entity.Slug;
import hu.ulyssys.java.course.maven.service.*;

import javax.enterprise.inject.spi.CDI;
import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

public class Main {

    @Inject
    private DogService dogService;

    @Inject
    private CatService catService;

    @Inject
    private SlugService slugService;

    @Inject
    private PDFExportService pdfExportService;

    @Inject
    private XLSExportService xlsExportService;

    public static void main(String[] args) {

        CDI<Object> cdi = CDI.getCDIProvider().initialize();
        Main main = cdi.select(Main.class).get();
        main.main(Arrays.asList(args));
    }

    protected void main(List<String> args) {

        for (int i = 0; i < 10; i++) {
            Dog dog = new Dog();
            dog.setId(Long.parseLong(i + ""));
            dog.setLegsNumber(i);
            dog.setName("Bodri");
            dogService.add(dog);
        }

        for (int i = 0; i < 10; i++) {
            Cat cat = new Cat();
            cat.setId(Long.parseLong(i + ""));
            cat.setLegsNumber(i);
            cat.setName("Cirmi");
            catService.add(cat);
        }

        for (int i = 0; i < 10; i++) {
            Slug slug = new Slug();
            slug.setId(Long.parseLong(i + ""));
            slug.setLegsNumber(i);
            slug.setName("Csigusz");
            slugService.add(slug);
        }
        pdfExportService.processExport();
        xlsExportService.processExport();
    }
}
