package hu.ulyssys.java.course.maven.service;

public interface PDFExportService {

    void processExport();
}
