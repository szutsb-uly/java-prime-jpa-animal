package hu.ulyssys.java.course.maven.entity;

public class Cat extends AbstractAnimal {
    @Override
    public AnimalType getType() {
        return AnimalType.CAT;
    }
}
