package hu.ulyssys.java.course.maven.service;

public interface XLSExportService {

    void processExport();
}
