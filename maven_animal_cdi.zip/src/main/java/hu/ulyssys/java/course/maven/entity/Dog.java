package hu.ulyssys.java.course.maven.entity;

public class Dog extends AbstractAnimal {
    @Override
    public AnimalType getType() {
        return AnimalType.DOG;
    }
}
