package hu.ulyssys.java.course.maven.service.impl;

import hu.ulyssys.java.course.maven.entity.Dog;
import hu.ulyssys.java.course.maven.service.DogService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DogServiceImpl extends AbstractServiceImpl<Dog> implements DogService {
}
