package hu.ulyssys.java.course.maven.service.impl;

import hu.ulyssys.java.course.maven.entity.Slug;
import hu.ulyssys.java.course.maven.service.SlugService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class SlugServiceImpl extends AbstractServiceImpl<Slug> implements SlugService {
}
