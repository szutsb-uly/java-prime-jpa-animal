package hu.ulyssys.java.course.maven.service;

import hu.ulyssys.java.course.maven.entity.Slug;

public interface SlugService extends CoreService<Slug> {
}
