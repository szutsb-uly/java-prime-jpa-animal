package hu.ulyssys.java.course.maven.service.impl;

import hu.ulyssys.java.course.maven.entity.Cat;
import hu.ulyssys.java.course.maven.service.CatService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CatServiceImpl extends AbstractServiceImpl<Cat> implements CatService {
}
