package hu.ulyssys.java.course.maven.service.impl;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import hu.ulyssys.java.course.maven.entity.Slug;
import hu.ulyssys.java.course.maven.service.PDFExportService;
import hu.ulyssys.java.course.maven.service.SlugService;

import javax.inject.Inject;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class PDFExportServiceImpl implements PDFExportService {
    @Inject
    private SlugService slugService;

    @Override
    public void processExport() {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("test.pdf"));
            document.open();
            for (Slug slug : slugService.getAll()) {
                document.add(new Paragraph("Id: " + slug.getId() + ", name:" + slug.getName()));
            }
            //Innen loptam https://stackoverflow.com/questions/35288194/how-to-add-url-to-pdf-document-using-itext
            Chunk chunk = new Chunk("Ulyssys.hu");
            chunk.setAnchor("https://ulyssys.hu/");
            document.add(chunk);
            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
