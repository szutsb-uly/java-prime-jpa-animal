package hu.ulyssys.java.course.maven.entity;

public class Slug extends AbstractAnimal {

    @Override
    public AnimalType getType() {
        return AnimalType.SLUG;
    }
}
